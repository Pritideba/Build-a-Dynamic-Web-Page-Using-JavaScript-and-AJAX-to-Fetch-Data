document.getElementById('fetchDataBtn').addEventListener('click', fetchData);

async function fetchData() {
    const loader = document.getElementById('loader');
    const dataContainer = document.getElementById('dataContainer');

    // Show loader
    loader.style.display = 'block';

    try {
        // Fetch data using the Fetch API
        const response = await fetch('https://jsonplaceholder.typicode.com/posts');

        // Check if the response is OK (status code 200)
        if (!response.ok) {
            throw new Error(`Error: ${response.status} ${response.statusText}`);
        }

        // Parse the JSON data
        const posts = await response.json();

        // Prepare HTML content
        let output = '';
        posts.forEach((post, index) => {
            output += `
                <div class="col-md-6">
                    <div class="card mb-3">
                        <img src="images/image${index % 4 + 1}.jpg" class="card-img-top" alt="Post Image">
                        <div class="card-body">
                            <h5 class="card-title">${post.title}</h5>
                            <p class="card-text">${post.body}</p>
                        </div>
                    </div>
                </div>
            `;
        });

        // Insert the content into the DOM
        dataContainer.innerHTML = output;
    } catch (error) {
        // Display error message if something goes wrong
        dataContainer.innerHTML = `<p class="text-danger">${error.message}</p>`;
    } finally {
        // Hide loader
        loader.style.display = 'none';
    }
}
